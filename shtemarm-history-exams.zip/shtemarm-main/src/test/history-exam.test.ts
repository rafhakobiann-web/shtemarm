import { describe, expect, it } from "vitest";
import { readFileSync } from "node:fs";
import { resolve } from "node:path";

type Unit = {
  id: string;
  kind: "mc" | "set" | "seq" | "match";
  passage: string;
  questions?: { n: string; stem: string; options: Record<string, string>; answer: string }[];
  answer?: number[] | Record<string, number>;
};
const data = JSON.parse(readFileSync(resolve(process.cwd(), "public/data/history-tests.json"), "utf8")) as {
  tests: { id: number; tasks: Unit[] }[];
};

const points = (u: Unit) => (u.kind === "mc" ? u.questions?.length ?? 0 : 1);

describe("Armenian history sample exams (tests 1–4)", () => {
  it.each([1, 2, 3, 4])("test %i has 70 tasks worth 80 points", (id) => {
    const test = data.tests.find((t) => t.id === id);
    expect(test?.tasks).toHaveLength(70);
    expect(test!.tasks.reduce((sum, u) => sum + points(u), 0)).toBe(80);
  });

  it.each([1, 2, 3, 4])("test %i answers point at real options", (id) => {
    const test = data.tests.find((t) => t.id === id)!;
    for (const u of test.tasks) {
      if (u.kind === "mc") for (const q of u.questions ?? []) expect(q.options).toHaveProperty(q.answer);
      if (u.kind === "seq") expect([...(u.answer as number[])].sort()).toEqual((u.answer as number[]).map((_, i) => i + 1).sort());
    }
  });
});
